# Portofolio Daffa Nailul Huda

Website portofolio bertema luar angkasa menggunakan HTML, CSS, dan JavaScript vanilla. Tidak membutuhkan database, framework, atau server backend.

## Menjalankan di komputer
1. Ekstrak file ZIP.
2. Buka folder `portfolio-daffa` di Visual Studio Code.
3. Buka `index.html` langsung di browser atau jalankan dengan ekstensi Live Server.

## Upload gratis ke internet dengan GitHub Pages
GitHub Pages dapat meng-host website statis secara gratis. Kamu perlu akun GitHub sendiri dan perlu melakukan langkah berikut:
1. Masuk ke https://github.com dan buat akun atau login.
2. Buat repository baru, misalnya `portfolio-daffa`.
3. Upload semua isi folder ini (`index.html`, `style.css`, `script.js`, folder `assets`, dan `README.md`) ke repository tersebut. Jangan upload file CV pribadi.
4. Buka **Settings → Pages** pada repository.
5. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
7. Tunggu proses publikasi selesai. GitHub akan menampilkan alamat website yang dapat dibuka orang lain, biasanya berbentuk `https://USERNAME.github.io/portfolio-daffa/`.

Nama menu atau tampilan GitHub bisa berubah sewaktu-waktu. Link baru aktif setelah GitHub Pages selesai menerbitkan situs.

## Isi folder
- `index.html` — struktur dan isi halaman.
- `style.css` — desain, responsif, animasi, dan tema.
- `script.js` — navigasi, animasi teks, filter proyek, modal detail, salin email, dan formulir kontak.
- `assets/profile.jpeg` — foto profil yang diambil dari CV yang diberikan.

## Fitur
- Layout responsif untuk desktop dan perangkat seluler.
- Tema gelap/terang dengan preferensi disimpan di browser.
- Animasi teks, reveal saat scroll, indikator progres, latar bintang bergerak di canvas, meteor, nebula, planet melayang, parallax pointer, dan efek glow.
- Navigasi mobile dan penanda bagian yang sedang dibuka.
- Filter kartu proyek dan modal detail proyek.
- Tombol salin email.
- Form kontak yang menyiapkan draft melalui aplikasi email; tidak mengirim pesan otomatis.
- Tahun footer otomatis.

## Sebelum dipublikasikan
- Pastikan kamu nyaman menampilkan email di situs publik. Demi privasi, alamat rumah lengkap dan nomor telepon pribadi tidak ditampilkan pada versi ini.
- Kartu proyek contoh/ide perlu diperbarui agar sesuai karya yang benar-benar sudah dibuat.
- Indikator skill hanyalah ilustrasi, bukan hasil tes atau sertifikasi.
