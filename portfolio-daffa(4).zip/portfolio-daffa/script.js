const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

// Tahun otomatis di footer
$('#year').textContent = new Date().getFullYear();

// Navigasi mobile
const menuToggle = $('#menuToggle');
const navLinks = $('#navLinks');
menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
$$('.nav-link').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

// Tema terang/gelap; pilihan disimpan selama sesi browser melalui localStorage
const themeToggle = $('#themeToggle');
try {
  if (localStorage.getItem('daffa-portfolio-theme') === 'light') document.body.classList.add('light-theme');
} catch (_) {}
function updateThemeIcon() {
  const light = document.body.classList.contains('light-theme');
  themeToggle.textContent = light ? '☾' : '☼';
  themeToggle.setAttribute('aria-label', light ? 'Gunakan tema gelap' : 'Gunakan tema terang');
}
updateThemeIcon();
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('light-theme');
  const theme = document.body.classList.contains('light-theme') ? 'light' : 'dark';
  try { localStorage.setItem('daffa-portfolio-theme', theme); } catch (_) {}
  updateThemeIcon();
});

// Animasi teks di hero
const typingText = $('#typingText');
const phrases = ['teknologi', 'website', 'server', 'elektronika'];
let phraseIndex = 0, charIndex = 0, deleting = false;
function typeLoop() {
  const phrase = phrases[phraseIndex];
  typingText.textContent = phrase.slice(0, charIndex);
  if (!deleting && charIndex < phrase.length) { charIndex++; setTimeout(typeLoop, 105); }
  else if (!deleting) { deleting = true; setTimeout(typeLoop, 1250); }
  else if (charIndex > 0) { charIndex--; setTimeout(typeLoop, 55); }
  else { deleting = false; phraseIndex = (phraseIndex + 1) % phrases.length; setTimeout(typeLoop, 250); }
}
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) setTimeout(typeLoop, 700);

// Reveal saat elemen masuk ke layar
const revealItems = $$('.reveal');
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('in-view'); revealObserver.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => revealObserver.observe(item));
} else revealItems.forEach(item => item.classList.add('in-view'));

// Progress bar dan navigasi aktif
const progressBar = $('#scrollProgress');
const navSections = $$('main section[id]');
function updateScrollUI() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  progressBar.style.width = `${scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0}%`;
  let current = 'home';
  navSections.forEach(section => { if (window.scrollY >= section.offsetTop - 170) current = section.id; });
  $$('.nav-link').forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${current}`));
}
window.addEventListener('scroll', updateScrollUI, { passive: true });
updateScrollUI();

// Filter kartu proyek
const filterButtons = $$('.filter-btn');
const projectCards = $$('.project-card');
const projectCount = $('#projectCount');
filterButtons.forEach(button => button.addEventListener('click', () => {
  const filter = button.dataset.filter;
  filterButtons.forEach(item => item.classList.toggle('active', item === button));
  let visible = 0;
  projectCards.forEach(card => {
    const show = filter === 'all' || card.dataset.category === filter;
    card.classList.toggle('hidden', !show);
    if (show) visible++;
  });
  projectCount.textContent = visible;
}));

// Modal detail proyek
const projectDialog = $('#projectDialog');
$$('.project-detail').forEach(button => button.addEventListener('click', () => {
  $('#dialogTitle').textContent = button.dataset.title;
  $('#dialogDescription').textContent = button.dataset.description;
  const stack = $('#dialogStack');
  stack.replaceChildren();
  button.dataset.stack.split(',').map(value => value.trim()).forEach(value => {
    const tag = document.createElement('span'); tag.textContent = value; stack.appendChild(tag);
  });
  if (typeof projectDialog.showModal === 'function') projectDialog.showModal();
}));
$('#dialogClose').addEventListener('click', () => projectDialog.close());
$('#dialogOk').addEventListener('click', () => projectDialog.close());
projectDialog.addEventListener('click', event => { if (event.target === projectDialog) projectDialog.close(); });

// Salin alamat email
const emailAddress = 'daffa99nhd@gmail.com';
const toast = $('#toast');
let toastTimeout;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 2400);
}
$('#copyEmail').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(emailAddress);
    $('#copyStatus').textContent = 'Email berhasil disalin.';
    showToast('Alamat email disalin ke clipboard.');
  } catch (_) {
    $('#copyStatus').textContent = `Silakan salin manual: ${emailAddress}`;
    showToast('Clipboard tidak tersedia. Email ditampilkan di bagian kontak.');
  }
});

// Form kontak menyiapkan draft email, tidak mengirim otomatis
$('#contactForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = $('#senderName').value.trim();
  const senderEmail = $('#senderEmail').value.trim();
  const message = $('#senderMessage').value.trim();
  if (!name || !senderEmail || !message) { showToast('Lengkapi semua kolom terlebih dahulu.'); return; }
  const subject = encodeURIComponent(`Pesan portofolio dari ${name}`);
  const body = encodeURIComponent(`Halo Daffa,\n\n${message}\n\nSalam,\n${name}\nEmail: ${senderEmail}`);
  window.location.href = `mailto:${emailAddress}?subject=${subject}&body=${body}`;
});


// Canvas bintang bergerak, meteor sesekali, dan parallax halus untuk nuansa luar angkasa.
(() => {
  const canvas = document.getElementById('starCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reducedMotion || !ctx) return;
  let width = 0, height = 0, stars = [], meteors = [], frame = 0;
  const pointer = { x: 0, y: 0 };
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth; height = window.innerHeight;
    canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.min(190, Math.floor(width * height / 6500));
    stars = Array.from({ length: count }, () => ({ x: Math.random()*width, y: Math.random()*height, r: Math.random()*1.35+.2, a: Math.random()*.65+.2, phase: Math.random()*Math.PI*2, speed: Math.random()*.018+.004, depth: Math.random()*.8+.2 }));
  }
  function spawnMeteor() {
    if (meteors.length < 2 && Math.random() < .012) meteors.push({ x: Math.random()*width*.9, y: Math.random()*height*.35, vx: 5+Math.random()*4, vy: 2+Math.random()*3, life: 0, max: 38+Math.random()*25 });
  }
  function draw() {
    frame++;
    ctx.clearRect(0, 0, width, height);
    for (const s of stars) {
      s.phase += s.speed;
      const alpha = s.a * (.65 + .35*Math.sin(s.phase));
      const px = s.x + pointer.x*s.depth*8, py = s.y + pointer.y*s.depth*8;
      ctx.beginPath(); ctx.arc(px, py, s.r, 0, Math.PI*2);
      ctx.fillStyle = `rgba(${s.r>1.1?'190,204,255':'225,232,255'},${alpha})`; ctx.fill();
      if (s.r > 1.15 && Math.sin(s.phase) > .97) { ctx.strokeStyle = `rgba(160,190,255,${alpha*.5})`; ctx.beginPath(); ctx.moveTo(px-4,py); ctx.lineTo(px+4,py); ctx.moveTo(px,py-4); ctx.lineTo(px,py+4); ctx.stroke(); }
    }
    spawnMeteor();
    meteors = meteors.filter(m => m.life < m.max);
    for (const m of meteors) {
      m.x += m.vx; m.y += m.vy; m.life++;
      const alpha = Math.sin(Math.PI*m.life/m.max)*.8;
      const tail = ctx.createLinearGradient(m.x-m.vx*8,m.y-m.vy*8,m.x,m.y);
      tail.addColorStop(0,'rgba(120,160,255,0)'); tail.addColorStop(1,`rgba(190,220,255,${alpha})`);
      ctx.strokeStyle=tail;ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(m.x-m.vx*8,m.y-m.vy*8);ctx.lineTo(m.x,m.y);ctx.stroke();
    }
    requestAnimationFrame(draw);
  }
  window.addEventListener('resize', resize, { passive: true });
  window.addEventListener('pointermove', e => { pointer.x=(e.clientX/Math.max(width,1)-.5)*2; pointer.y=(e.clientY/Math.max(height,1)-.5)*2; }, { passive: true });
  resize(); draw();
})();
